<?php 

$config['database']['default'] 	= [

	'driver'	=> 'mysql',
	'hostname' 	=> 'localhost',
	'username'	=> 'root',
	'password' 	=> '',
	'database'  => '',
	'port'		=> '3306'

];