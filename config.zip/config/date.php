<?php 
$config['date']['timezone'] = 'Asia/Jakarta';