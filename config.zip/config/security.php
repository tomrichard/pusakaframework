<?php 
$config['security']['key'] = '';