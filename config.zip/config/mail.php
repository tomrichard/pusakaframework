<?php 
$config['mail']['default'] = [
	"host" 		=> "",
	"port"		=> 25,
	"security"	=> "tls",
	"username"	=> "",
	"password"	=> ""
];