<?php 
$config['vendor'] = [

	"<<your_vendor_name>>" => [
		"<<key>>" => "<<value>>"
	]

];