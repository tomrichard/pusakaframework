<?php 
$config['routes'] = [
	':default' 	=> 'welcome'
];