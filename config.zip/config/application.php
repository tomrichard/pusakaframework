<?php 
/*
|================================= 
| application config
|================================= */
$config['application']['apiurl'] = URL . 'app/microservice/api/';