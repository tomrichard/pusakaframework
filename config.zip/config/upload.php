<?php 
/*
| Upload
|=============================== */
$config['upload']['image'] = [
	'link' 		=> ':root:/storage/@filename',
	'save'		=> '@root/storage/media/@filename',
	'max'		=> '100 KB',
	'allowed'	=> 'jpg|jpeg|png|gif',
	'encrypt'	=> FALSE,
	'duplicate'	=> '_@number'
];